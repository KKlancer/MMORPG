﻿using UnityEngine;
using System.Collections;
using XLua;

public class UIRootCtrl : MonoBehaviour
{
    public Transform ContainerCenter;

    // Use this for initialization
    void Start()
    {

    }
}