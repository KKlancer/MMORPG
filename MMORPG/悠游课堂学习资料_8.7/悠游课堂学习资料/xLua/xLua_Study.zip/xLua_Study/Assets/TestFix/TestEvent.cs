﻿using UnityEngine;
using System.Collections;

public class TestEvent : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

    public void TestAA()
    {
        Debug.Log("执行了AA");
    }
}
