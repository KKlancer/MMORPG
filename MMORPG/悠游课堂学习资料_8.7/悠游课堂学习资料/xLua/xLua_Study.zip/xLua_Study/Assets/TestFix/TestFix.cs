﻿using UnityEngine;
using System.Collections;
using XLua;

[Hotfix]
public class TestFix
{
    public int Add(int a, int b)
    {
        return a - b;
    }
}
