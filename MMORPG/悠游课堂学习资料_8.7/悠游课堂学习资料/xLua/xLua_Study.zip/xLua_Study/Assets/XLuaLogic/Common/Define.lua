﻿print('启动了Define.lua')

CtrlNames={
	MessageCtrl = "MessageCtrl",
	UIRootCtrl = "UIRootCtrl"
}

ViewNames={
	"UIRootView",
	"MessageView"
}

--这里要把常用的引擎类型都加入进来
WWW = CS.UnityEngine.WWW;
GameObject = CS.UnityEngine.GameObject;
Color = CS.UnityEngine.Color;
Vector3 = CS.UnityEngine.Vector3;