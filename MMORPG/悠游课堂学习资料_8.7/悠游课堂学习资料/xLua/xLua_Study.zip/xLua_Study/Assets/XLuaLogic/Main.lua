﻿require "XLuaLogic/GameInit"

GameInit.Init();